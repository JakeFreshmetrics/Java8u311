The licenses for Third Party components included with this product can 
be found under the /legal/jdk subdirectory. Each component's license is 
available as a separate markdown (.md) file.
